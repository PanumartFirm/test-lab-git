@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
           
                <div class="panel-heading">
                <br>
                <form method="post"  action="{{ route('account.store') }}">
                     {{ csrf_field() }}
                 <div class="form-group" >
                        <label for="ACC_No" >หมายเลขบัชญี </label>
                        <input type="text" name="ACC_No" class="form-control" >          
                </div>
                <div class="form-group" >
                        <label for="ACC_Name" >ชื่อ </label>
                        <input type="text" name="ACC_Name" class="form-control" >          
                </div>
                <div class="form-group" >
                        <label for="ACC_Surname" >นามสกุล </label>
                        <input type="text" name="ACC_Surname" class="form-control" >          
                </div>
                <div class="form-group" >
                        <label for="Balance" >เงิน </label>
                        <input type="text" name="Balnace" class="form-control" >          
                </div>

               <div>
               <button type="submit" class="btn btn-default" >เปิดบัชญี่ </button>
               </div>
             </form>
                
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
