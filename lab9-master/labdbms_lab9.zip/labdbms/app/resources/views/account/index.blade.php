@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
            <div>
            <a href="{{ route('account.create')}}" class="btn btn-success">เปิดบัชญี</a> 
            </div>
                <div class="panel-heading">
                <br>
                <table class="table">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">ACC_No</th>
      <th scope="col">ACC_Name</th>
      <th scope="col">ACC_Surname</th>
      <th scope="col">Balnace</th>
      <th scope="col" colspan=2 align="center">Operation</th>
    </tr>
  </thead>
  <?php $i=1; ?>
   @foreach($account as $row)
  <tbody> 
    <tr>
      <th scope="row">1</th>
      <td>{{ $row->ACC_No }}</td>
      <td>{{ $row->ACC_Name }}</td>
      <td>{{ $row->ACC_Surname }}</td>
      <td>{{ $row->Balnace }}</td>
      <td> <a href="{{ route('account.edit',$row->id) }}"class="btn btn-warning">Edit</a></td>
      <td><form action=" {{ route('account.destroy',$row->id )}}" method="post">
         @csrf
         @method("Delete")
         <button class="btn btn-danger"> Delete </button>
         </form>
         </td>
    </tr>
  </tbody>
  @endforeach
</table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
